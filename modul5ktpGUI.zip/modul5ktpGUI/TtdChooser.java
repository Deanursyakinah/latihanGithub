public class TtdChooser {
    private static String selectedTtdPath;

    public static String getSelectedTtdPath() {
        return selectedTtdPath;
    }

    public static void setSelectedTtdPath(String path) {
        selectedTtdPath = path;
    }
}
