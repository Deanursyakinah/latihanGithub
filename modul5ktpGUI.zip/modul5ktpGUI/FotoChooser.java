public class FotoChooser {
    private static String selectedFotoPath;

    public static String getSelectedFotoPath() {
        return selectedFotoPath;
    }

    public static void setSelectedFotoPath(String path) {
        selectedFotoPath = path;
    }
}
