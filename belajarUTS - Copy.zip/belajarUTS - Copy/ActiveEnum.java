package belajarUTS;

public enum ActiveEnum {
    INACTIVE, ACTIVE
}
