package PBO.Week5.model;

public interface InterfaceStatus {
    int hadir = 1;
    int alpha = 0;
}
