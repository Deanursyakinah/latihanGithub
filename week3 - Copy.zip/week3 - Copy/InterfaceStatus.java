package PBO.week3;

public interface InterfaceStatus {
    final int dead = 0;
    final int alive = 1;
    //ini otomatis konstanta 

    abstract boolean isAlive();
    //ini jadinya method abstract
    abstract String printData();
}
