package PBO.week3;

public abstract class Animal {
    String name;
    int age;
    String food;
    String gender;
    int alive;
}
