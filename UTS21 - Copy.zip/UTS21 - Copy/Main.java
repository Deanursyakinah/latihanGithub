package UTS21;
import UTS21.view.*;

public class Main {
    public static void main(String[] args) {
        MainMenu.view();
    }
}
