package UTS21.view;
import javax.swing.JOptionPane;

public class viewShowMessage {
    public static void method4(String hasil) {
        JOptionPane.showMessageDialog(null, hasil);
    }
}
