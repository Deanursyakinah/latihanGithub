package UTS21.view;
import javax.swing.JOptionPane;

public class ubahStatus {
    public static void method2(String hasil) {
        JOptionPane.showMessageDialog(null, "Perubahan status :\n" + hasil);
    }
}
