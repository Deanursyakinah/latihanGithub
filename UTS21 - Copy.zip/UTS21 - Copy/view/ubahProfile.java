package UTS21.view;
import javax.swing.JOptionPane;

public class ubahProfile {
    public static void method5(String hasil) {
        JOptionPane.showMessageDialog(null, "Perubahan profil pengguna:\n" + hasil);
    }
}
