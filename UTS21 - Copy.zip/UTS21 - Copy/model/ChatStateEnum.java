package UTS21.model;

public enum ChatStateEnum {
    PINNED, UNPINNED, MUTED, UNMUTED, HIDE, DELETED
}
