package UTS21.model;

public enum MessageAvailabilityEnum {
    AVAILABLE, DELETED
}
