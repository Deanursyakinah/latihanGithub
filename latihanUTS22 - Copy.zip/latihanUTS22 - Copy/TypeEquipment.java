package latihanUTS22;

public enum TypeEquipment {
    ARMOR, MAGIC_THAT, WEAPON
}
