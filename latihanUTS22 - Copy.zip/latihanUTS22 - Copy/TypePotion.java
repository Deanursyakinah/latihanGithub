package latihanUTS22;

public enum TypePotion {
    HP, MP
}
