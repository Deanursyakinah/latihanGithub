package latihanUTS22;

public enum TypeItem {
    EQUIPMENT, POTION
}
